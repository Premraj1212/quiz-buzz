## A Console Game Development

### Chalk library used as decorator

### Game ideas
> App support multiple players
> 
> Every player 2 attempts to guess number correctly
> 
> Points are calculated for right guess and winner is announced
> 
